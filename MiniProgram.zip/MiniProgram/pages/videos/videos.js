// 随机生成颜色
function getRandomColor () {
  let rgb = []
  for (let i = 0 ; i < 3; ++i) {
    let color = Math.floor(Math.random() * 256).toString(16)
    color = color.length == 1 ? '0' + color : color
    rgb.push(color)
  }
  return '#' + rgb.join('')
}

Page({
  /**
   * 页面的初始数据
   */
  data: {
    danmuList:
    [{
      text: '',
      color: '#ff0000',
      time: 1
    }],

    videos:[],
    inputValue:"",
    video_src:['http://localhost:8080/videos/清明节.mp4'],
    photo_url:['http://localhost:8080/assets/vphoto/qingmingjie.png']
  },

//传视频URL"后一个"按钮触发
translateURL:function(){
  var that = this
  wx.request({
    url: 'http://localhost:8080/translateURL', 
    success (res) {
      that.setData({
        video_src: res.data
      })
      console.log(res.data);
    }
  })
},
translateURL02:function(){
  var that = this
  wx.request({
    url: 'http://localhost:8080/translateURL02', 
    success (res) {
      that.setData({
        video_src: res.data
      })
      console.log(res.data);
    }
  })
},


//视频列表,界面加载触发
  onLoad:function(){
    var that = this;
    wx.request({
      url: 'http://localhost:8080/listVideos',
      success (res) {
        that.setData({
          videos:res.data
        })
        console.log(res.data);
      }
    })
  },

  onReady: function () {
    /**
   * 初始化视频
   */
    this.videoContext = wx.createVideoContext('myvideo')
  },
  // 绑定输入框事件
  bindInputBlur:function(e) {
    this.inputValue = e.detail.value
    console.log(this.inputValue)
  },
  // 绑定按钮事件
  bindSendDanmu () {
    this.videoContext.sendDanmu({
      text: this.inputValue,
      color: getRandomColor()
      
    })
  },
  playVideo:function(e){
    console.log(e.target.id);
    this.setData({
      video_src:"http://localhost:8080"+e.target.id
    })
  },
})