package com.team02.gennius_child.controller;

import com.alibaba.fastjson.JSONObject;
import com.team02.gennius_child.entity.WxUser;
import com.team02.gennius_child.mapper.WxUserMapper;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.io.IOException;
import java.util.UUID;

/**
 * @author 张峰源
 * @date 2021/6/23 22:52
 */
@Controller
public class LoginContorller {
    @Autowired
    private WxUserMapper wxUserMapper;
    @ResponseBody
    @RequestMapping("/login")
    public String login( String userInfo, String code, HttpSession session) throws IOException {
        //目前为测试ID
        String appid="wx12446a81a5d4b4f5";
        //密匙
        String secret="3d3b28ba14f65a0f94c69807b06f3581";

        String url = "https://api.weixin.qq.com/sns/jscode2session?appid="+appid+"&secret="+secret+"&js_code=" + code + "&grant_type=authorization_code";

        //创建okhttpclient对象，也可如下面的例子直接 new OkHttpClient()
        OkHttpClient client = new OkHttpClient().newBuilder().build();
        //因为默认请求为get，所以 get() 可省略
        Request request = new Request.Builder().url(url).get().build();
        Response response = client.newCall(request).execute();

        String values = response.body().string();

        WxUser wxUser =JSONObject.parseObject(userInfo,WxUser.class);

        JSONObject jsonObject=JSONObject.parseObject(values);

        wxUser.setOpenId(jsonObject.getString("openid"));

        wxUserMapper.addVideo(wxUser);
//        System.out.println(values);
        String key = UUID.randomUUID().toString();
//        System.out.println(key);//没有做控制错误
        session.setAttribute(key, values);
        return key;
    }
}
