package com.team02.gennius_child.entity;

/**
 * @author 张峰源
 * @date 2021/6/24 10:25
 */

public class WxUser {
    private String sessionKey;
    private String openId;
    private String nickName;
    private String avatarUrl;

    public void setSessionKey(String sessionKey) {
        this.sessionKey = sessionKey;
    }

    public String getNickName() {
        return nickName;
    }

    public void setNickName(String nickName) {
        this.nickName = nickName;
    }

    public String getAvatarUrl() {
        return avatarUrl;
    }

    public void setAvatarUrl(String avatarUrl) {
        this.avatarUrl = avatarUrl;
    }

    public WxUser() {
    }

    public String getSessionKey() {
        return sessionKey;
    }

    public void setSession(String session_key) {
        sessionKey = session_key;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    @Override
    public String toString() {
        return "WxUser{" +
                "sessionKey='" + sessionKey + '\'' +
                ", openId='" + openId + '\'' +
                ", nickName='" + nickName + '\'' +
                ", avatarUrl='" + avatarUrl + '\'' +
                '}';
    }
}
