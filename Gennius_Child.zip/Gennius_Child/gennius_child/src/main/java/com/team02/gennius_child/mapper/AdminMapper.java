package com.team02.gennius_child.mapper;

import com.team02.gennius_child.entity.Admin;
import org.apache.ibatis.annotations.*;

@Mapper
public interface AdminMapper {
    /**
     * 查询是否有该用户
     * */
    @Select("Select * from admin WHERE userName = #{admin.userName} AND password = #{admin.password} AND state = 0")
    Admin queryByAdmin(@Param("admin") Admin admin);


    @Select("SELECT * FROM  admin WHERE userName = #{admin.userName}")
    Admin hasExisted(@Param("admin") Admin admin);

    @Insert("INSERT INTO\n" +
            "\t\tadmin(userName,email,password,realName,age,phoneNumber,headPicture,addDate,state)\n" +
            "\t\tVALUES\n" +
            "\t\t(#{admin.userName},#{admin.email},#{admin.password},#{admin.realName},#{admin.age},#{admin.phoneNumber},#{admin.headPicture},#{admin.addDate},\n" +
            "\t\t#{admin.state})")
    int insertAdmin(@Param("admin") Admin admin);

    @Update("update admin\n" +
            "        <set>\n" +
            "            <if test=\"email != null\">email=#{email},</if>\n" +
            "            <if test=\"password != null\">password=#{password},</if>\n" +
            "            <if test=\"realName != null\">realName=#{realName},</if>\n" +
            "            <if test=\"age != null\">age = #{age},</if>\n" +
            "            <if test=\"phoneNumber != null\">phoneNumber=#{phoneNumber},</if>\n" +
            "            <if test=\"headPicture != null\">headPicture=#{headPicture},</if>\n" +
            "            <if test=\"updateDate != null\">updateDate=#{updateDate},</if>\n" +
            "        </set>\n" +
            "        where userName=#{userName}")
    int updateAdmin(@Param("admin") Admin admin);
}
