package com.team02.gennius_child.mapper;

import com.team02.gennius_child.entity.Videos;
import org.apache.ibatis.annotations.*;
import java.util.List;

@Mapper
public interface VideosMapper {

    @Insert("insert into videos(id,name,size,path,realpath,vphoto) values(null,#{video.name},#{video.size},#{video.path},#{video.realpath},#{video.vphoto})")
    public void addVideo(@Param("video") Videos videos);

    @Select("select id,name,size,path,realpath,vphoto from videos")
    public List<Videos> listVideos();

    @Delete("delete from videos where id = #{id}")
    public void deletevideo(@Param("id") Integer videoId);

    //查视频URL
    @Select("select path from videos where id=#{id}")
    public String translateURL(@Param("id") Integer Id);

    //查视频记录总数
    @Select("select count(id) from videos")
    public Integer count();

//    //查视频封面URL
//    @Select("select url from vphoto where id=#{id}")
//    public String Vphoto(@Param("id") Integer Id);

}
