package com.team02.gennius_child;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MiniprogramApplication {
	
	public static void main(String[] args) {
		SpringApplication.run(MiniprogramApplication.class, args);
	}
}
