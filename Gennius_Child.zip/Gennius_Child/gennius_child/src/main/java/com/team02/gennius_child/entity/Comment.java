package com.team02.gennius_child.entity;

import org.springframework.format.annotation.DateTimeFormat;

import java.util.Date;


/**
 * @author 张峰源
 * @date 2021/6/24 18:09
 */
public class Comment {
    private Integer id=0;
    private String  username;
    private String  content;
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private  Date time;
    private String image;


    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public Comment() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Date getTime() {
        return time;
    }

    public void setTime(Date time) {
        this.time = time;
    }
}
