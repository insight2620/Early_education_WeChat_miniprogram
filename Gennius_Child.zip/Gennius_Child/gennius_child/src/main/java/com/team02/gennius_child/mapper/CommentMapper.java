package com.team02.gennius_child.mapper;

import com.team02.gennius_child.entity.Comment;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * @author 张峰源
 * @date 2021/6/24 18:18
 */
@Mapper
public interface CommentMapper {



    @Insert("insert into comment(username,content,time) values(#{comment.username},#{comment.content},#{comment.time})")
    @Options(useGeneratedKeys=true,keyProperty="comment.id", keyColumn="id")
    public void addComment(@Param("comment") Comment comment);
    @Select("select comment.username,content,time,image from user,comment where user.username=comment.username")
    public List<Comment> showComment();


}
