package com.team02.gennius_child.mapper;

import com.team02.gennius_child.entity.Videos;
import com.team02.gennius_child.entity.WxUser;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

/**
 * @author 张峰源
 * @date 2021/6/24 14:30
 */
@Mapper
public interface WxUserMapper {
    @Insert("insert into user(id,username,image) values(#{wxUser.openId},#{wxUser.nickName},#{wxUser.avatarUrl})")
    public void addVideo(@Param("wxUser") WxUser wxUser);
}
