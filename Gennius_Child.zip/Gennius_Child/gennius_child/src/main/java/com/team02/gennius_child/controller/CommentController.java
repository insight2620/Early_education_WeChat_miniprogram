package com.team02.gennius_child.controller;


import com.alibaba.fastjson.JSONObject;
import com.team02.gennius_child.entity.Comment;
import com.team02.gennius_child.mapper.CommentMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * @author 张峰源
 * @date 2021/6/24 18:07
 */
@Controller
public class CommentController {
    @Autowired
    private CommentMapper commentMapper;
    @ResponseBody
    @RequestMapping("/addComment")
    public Map<String,String> addComment(String content ,String userInfo){

        SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date(System.currentTimeMillis());

        JSONObject jsonObject = JSONObject.parseObject(userInfo);
        Comment comment =new Comment();
        comment.setUsername(jsonObject.getString("nickName"));
        comment.setContent(content);
        comment.setTime(date);
        commentMapper.addComment(comment);
        Map<String,String> map =new LinkedHashMap<String, String>();
        map.put("status", "success");
        return map;
    }
    @ResponseBody
    @RequestMapping("/showComment")
    public List<Comment> showComment(){
        List<Comment> list=commentMapper.showComment();
        System.out.println(list);
        return list;
    }

}
