package com.team02.gennius_child.controller;

import com.team02.gennius_child.entity.Videos;
import com.team02.gennius_child.mapper.VideosMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.util.List;

@Controller
public class VideosController {

    /**上传地址*/
    @Value("${file.upload.path}")
    private String filePath;

    /**显示相对地址*/
    @Value("${file.upload.relative}")
    private String fileRelativePath;

    @Autowired
    private VideosMapper videosMapper;

    //后台视频管理界面,显示视频列表
    @RequestMapping("/VideoManage")
    public String addVideoForm(ModelMap model){
        //给list传视频列表
        List<Videos> videos02 = videosMapper.listVideos();
        model.put("videos02", videos02);
        //跳转页面
        return "background/backgroundStartAll";
    }

    //视频json数据,用于小程序视频列表
    @ResponseBody
    @RequestMapping("/listVideos")
    public List<Videos> listVideos(ModelMap model){

        return videosMapper.listVideos();
    }

    //视频添加
    @RequestMapping(value = "/addVideo",method = RequestMethod.POST)
    public String addVideo(Videos videos, MultipartFile upfile,ModelMap model) throws IOException {
        String filename = upfile.getOriginalFilename();
        File file = new File(filePath+"/"+filename);

        String realPath = file.getPath();
        Double size = file.length()/1024.0/1024;

        videos.setName(filename);
        videos.setSize(size);
        videos.setRealpath(realPath);
        videos.setvphoto("");
        String t = fileRelativePath.substring(0,fileRelativePath.length()-3);
        videos.setPath(t+"/"+filename);
        //将文件保存到指定文件夹
        upfile.transferTo(file);
        videosMapper.addVideo(videos);

        //刷新视频列表
        List<Videos> videos02 = videosMapper.listVideos();
        model.put("videos02", videos02);
        //跳转页面
        return "background/backgroundStartAll";
    }



    //根据id删除视频
    @RequestMapping("/deletevideo")
    public String deletevideo(Integer videoId,ModelMap model) {

        videosMapper.deletevideo(videoId);
        //刷新视频列表
        List<Videos> videos02 = videosMapper.listVideos();
        model.put("videos02", videos02);
        //跳转页面
        return "background/backgroundStartAll";
    }

    //传视频URL
    Integer id=1;
    @ResponseBody
    @RequestMapping("/translateURL")
    public String translateURL() {
        id++;//下一个
        Integer num = videosMapper.count();//查视频记录总数
        if(id>num){id=1;}//限制查询的视频id不超界,循环
        String url = "http://localhost:8080"+videosMapper.translateURL(id);
        System.out.println("视频总数为:"+num+",当前为:"+id);
        System.out.println("URL:"+url);
        return url;
    }
    @ResponseBody
    @RequestMapping("/translateURL02")
    public String translateURL02() {
        id--;//上一个
        Integer num = videosMapper.count();
        if(id<1){id=num;}//限制查询的视频id不超界,循环
        String url = "http://localhost:8080"+videosMapper.translateURL(id);
        System.out.println("视频总数为:"+num+",当前为:"+id);
        System.out.println("URL:"+url);
        return url;
    }

    @GetMapping("/videosUpLoadTurnTo")
    public String VideosUpLoadTurnTo(){
        return "/background/videos/videoUpLoad";
    }
}
