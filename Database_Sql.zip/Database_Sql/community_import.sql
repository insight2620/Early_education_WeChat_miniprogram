/*
Navicat MySQL Data Transfer

Source Server         : 127.0.0.1_3306
Source Server Version : 80021
Source Host           : 127.0.0.1:3306
Source Database       : miniprogram

Target Server Type    : MYSQL
Target Server Version : 80021
File Encoding         : 65001

Date: 2021-06-24 21:24:59
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for comment
-- ----------------------------
DROP TABLE IF EXISTS `comment`;
CREATE TABLE `comment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userid` varchar(255) DEFAULT NULL,
  `time` datetime DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `userid` (`userid`),
  CONSTRAINT `userid` FOREIGN KEY (`userid`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of comment
-- ----------------------------
INSERT INTO `comment` VALUES ('17', null, '2021-06-24 20:26:37', '2022', '你好');
INSERT INTO `comment` VALUES ('18', null, '2021-06-24 20:26:42', '2022', '小程序');

-- ----------------------------
-- Table structure for reply
-- ----------------------------
DROP TABLE IF EXISTS `reply`;
CREATE TABLE `reply` (
  `parent_id` int NOT NULL,
  `reply_id` int NOT NULL,
  `reply_name` varchar(255) DEFAULT NULL,
  `reply_time` datetime DEFAULT NULL,
  `reply_content` varchar(255) DEFAULT NULL,
  `replay_useid` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`parent_id`,`reply_id`),
  KEY `userid0` (`replay_useid`),
  CONSTRAINT `userid0` FOREIGN KEY (`replay_useid`) REFERENCES `user` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of reply
-- ----------------------------

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` varchar(255) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('o8HUk6qxWl7kpGqk4ILxIKkfdavY', '2022', 'https://thirdwx.qlogo.cn/mmopen/vi_32/DxA89AgRfq9SGZiaW4xa4TVibWmSDXibrCibtnjicaITaVfia1TekvoicRkPpT5F4ghfV7kpiaicYgbmAXpGyVPxXib0sy4Q/132');
