/*
SQLyog Ultimate v11.27 (32 bit)
MySQL - 5.7.28 : Database - miniprogram
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`miniprogram` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;

USE `miniprogram`;


/*Table structure for table `videos` */

DROP TABLE IF EXISTS `videos`;

CREATE TABLE `videos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL COMMENT '视频名称',
  `size` double DEFAULT NULL COMMENT '视频大小Mb',
  `path` varchar(128) DEFAULT NULL COMMENT '访问路径',
  `realpath` varchar(128) DEFAULT NULL COMMENT '物理路径',
	`vphoto` varchar(128) DEFAULT NULL COMMENT '视频封面',
  `createtime` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '添加事件',
  `updatetime` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '修改事件',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=utf8mb4 COMMENT='早教视频表';

/*Data for the table `videos` */

insert  into `videos`(`id`,`name`,`size`,`path`,`realpath`,`vphoto`,`createtime`,`updatetime`) 
values (1,'清明节.mp4','10.00','/videos/清明节.mp4','D:\\videos\\清明节.mp4','/assets/vphoto/qingmingjie.png','2021-06-21 09:45:07','2021-06-21 09:45:07'),
(2,'万圣节.mp4','75.00','/videos/万圣节.mp4','D:\\videos\\万圣节.mp4','/assets/vphoto/wanshengjie.png','2021-06-21 09:45:07','2021-06-21 09:45:07'),
(3,'向日葵.mp4','37.00','/videos/向日葵.mp4','D:\\videos\\向日葵.mp4','/assets/vphoto/xiangrikui.png','2021-06-21 09:45:07','2021-06-21 09:45:07'),
(4,'玉米.mp4','33.00','/videos/玉米.mp4','D:\\videos\\玉米.mp4','/assets/vphoto/yvmi.png','2021-06-21 09:45:07','2021-06-21 09:45:07'),
(5,'元宵节.mp4','57.00','/videos/元宵节.mp4','D:\\videos\\元宵节.mp4','/assets/vphoto/yuanxiaojie.png','2021-06-21 09:45:07','2021-06-21 09:45:07'),
(6,'清明节.mp4','10.00','/videos/清明节.mp4','D:\\videos\\清明节.mp4','/assets/vphoto/qingmingjie.png','2021-06-21 09:45:07','2021-06-21 09:45:07'),
(7,'万圣节.mp4','75.00','/videos/万圣节.mp4','D:\\videos\\万圣节.mp4','/assets/vphoto/wanshengjie.png','2021-06-21 09:45:07','2021-06-21 09:45:07'),
(8,'向日葵.mp4','37.00','/videos/向日葵.mp4','D:\\videos\\向日葵.mp4','/assets/vphoto/xiangrikui.png','2021-06-21 09:45:07','2021-06-21 09:45:07'),
(9,'玉米.mp4','33.00','/videos/玉米.mp4','D:\\videos\\玉米.mp4','/assets/vphoto/yvmi.png','2021-06-21 09:45:07','2021-06-21 09:45:07'),
(10,'元宵节.mp4','57.00','/videos/元宵节.mp4','D:\\videos\\元宵节.mp4','/assets/vphoto/yuanxiaojie.png','2021-06-21 09:45:07','2021-06-21 09:45:07');
;


/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
