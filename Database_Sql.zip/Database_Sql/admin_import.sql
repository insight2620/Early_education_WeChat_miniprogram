/*
 Navicat MySQL Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 50734
 Source Host           : localhost:3306
 Source Schema         : miniprogram

 Target Server Type    : MySQL
 Target Server Version : 50734
 File Encoding         : 65001

 Date: 23/06/2021 20:50:07
*/

CREATE DATABASE /*!32312 IF NOT EXISTS*/`miniprogram` /*!40100 DEFAULT CHARACTER SET utf8mb4 */;
USE `miniprogram`;


SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `userName` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `email` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `password` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `realName` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `age` int(11) NULL DEFAULT NULL,
  `phoneNumber` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `headPicture` varchar(45) CHARACTER SET utf8 COLLATE utf8_general_ci NULL DEFAULT NULL,
  `addDate` date NULL DEFAULT NULL,
  `updateDate` date NULL DEFAULT NULL,
  `state` int(11) NULL DEFAULT 0 COMMENT '1：正常\n2：冻结\n3：删除',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `name_UNIQUE`(`userName`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES (1, '1037377970@qq.com', '1037377970@qq.com', '123456', 'wangfulin', 20, '15759206413', NULL, '2018-12-20', '2018-12-27', 0);
INSERT INTO `admin` VALUES (2, 'wangfulin@qq.com', NULL, '55665566g', NULL, NULL, NULL, NULL, NULL, '2018-12-20', 0);
INSERT INTO `admin` VALUES (4, '103737970@qq.com', '312312@qq.com', '31231', '312312', NULL, '312312', NULL, '2018-12-25', NULL, 0);
INSERT INTO `admin` VALUES (5, '123@qq.com', '123@qq.com', '123', 'guomao', 22, '12345678996', NULL, '2021-06-09', '2021-06-11', 0);

